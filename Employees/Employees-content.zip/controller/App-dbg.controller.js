// @ts-nocheck
sap.ui.define([
    "sap/ui/core/mvc/Controller"
], function (Controller) {

    return Controller.extend("hrolltfg.Employees.controller.App", {

        onInit: function () {

        }
    });
});    